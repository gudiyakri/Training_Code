package com.springboot.crudProjectWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudProjectWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudProjectWebApplication.class, args);
	}

}
